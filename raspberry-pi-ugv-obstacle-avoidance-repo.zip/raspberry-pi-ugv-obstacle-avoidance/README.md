# Raspberry Pi UGV – Obstacle Avoidance

A Raspberry Pi based Unmanned Ground Vehicle (UGV) using:

- Raspberry Pi
- TFmini Plus LiDAR over UART
- 3 × Grove Ultrasonic V2.0 sensors
- L298N motor driver
- Differential-drive motors

The obstacle-avoidance logic uses the **front ultrasonic sensor** to detect an obstacle and the **left/right ultrasonic sensors** to select a direction.

## Features

- 3-direction ultrasonic obstacle detection
- Median filtering using 5 ultrasonic measurements
- 40 cm obstacle threshold
- Automatic left/right turning
- 10-second reverse when front and both sides are blocked
- TFmini Plus distance and signal-strength monitoring
- Safety stop if the front sensor fails
- GPIO cleanup and motor stop on exit

## Hardware

| Component | Connection |
|---|---|
| Left Grove Ultrasonic SIG | GPIO 17 |
| Front Grove Ultrasonic SIG | GPIO 27 |
| Right Grove Ultrasonic SIG | GPIO 22 |
| L298N IN1 | GPIO 23 |
| L298N IN2 | GPIO 24 |
| L298N IN3 | GPIO 25 |
| L298N IN4 | GPIO 26 |
| TFmini Plus UART | `/dev/ttyS0` |
| TFmini Plus baud rate | 115200 |

> GPIO numbering is **BCM numbering**, not physical pin numbering.

## Obstacle Logic

### 1. Front is clear

If:

`Front >= 40 cm`

The UGV moves forward.

### 2. Front is blocked

If:

`Front < 40 cm`

The UGV checks the left and right sensors.

### 3. One side is clear

- Right >= 40 cm and left < 40 cm → turn right
- Left >= 40 cm and right < 40 cm → turn left

### 4. Both sides are clear

The UGV chooses the side with more available space.

### 5. All three directions are blocked

The UGV:

1. Reverses for 10 seconds.
2. Stops.
3. Re-checks left and right.
4. Turns toward an available side.
5. Stops if all directions remain blocked.

## TFmini Plus

The TFmini Plus is read using its UART frame:

`59 59`

The code validates the frame checksum before accepting the distance.

The LiDAR output is displayed approximately every 2 seconds.

## Raspberry Pi Setup

Install the required Python packages:

```bash
sudo apt update
sudo apt install python3-serial python3-rpi.gpio
```

Check the serial device:

```bash
ls -l /dev/ttyS0
```

Run the program:

```bash
python3 ugv_obstacle_avoidance.py
```

Stop it with:

```text
Ctrl + C
```

The program automatically stops the motors and cleans up GPIO when it exits.

## Repository Structure

```text
raspberry-pi-ugv-obstacle-avoidance/
├── ugv_obstacle_avoidance.py
├── requirements.txt
├── README.md
├── .gitignore
└── LICENSE
```

## Important Safety Notes

- Test the motor direction with the wheels lifted from the ground first.
- Make sure the motor driver and Raspberry Pi have suitable power supplies.
- Do not power motors directly from the Raspberry Pi GPIO.
- Confirm the TFmini Plus UART voltage/interface requirements before wiring.
- Keep an emergency power switch available during initial testing.

## Project Status

Prototype obstacle-avoidance control software.

Future improvements can include:

- PWM speed control
- smoother turns
- non-blocking reverse/turn timing
- LiDAR-based front obstacle confirmation
- motor encoders
- PID speed control
- ROS/ROS 2 integration
- autonomous navigation and mapping
